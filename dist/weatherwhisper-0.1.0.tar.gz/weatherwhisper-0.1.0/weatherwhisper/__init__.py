"""
WeatherWhisper - A command-line tool for fetching and displaying weather information.
"""

__version__ = "0.1.0"
